<?php
// +----------------------------------------------------------------------
// | Tchat 
// +----------------------------------------------------------------------
// | Copyright (c) 2014 http://www.tealun.com
// +----------------------------------------------------------------------
// | Author: Tealun Du <tealun@tealun.com> <http://www.tealun.com>
// +----------------------------------------------------------------------

namespace Realestate\Controller;
use Think\Controller;

class ProjectsController extends Controller{
	
	public function index(){
	
	}
	
	/**
	 * 项目简介
	 * 
	 */
	public function brief(){
	
	}
	
	/**
	 * 项目详细信息
	 * 
	 */
	public function details(){
	
	}
	
	/**
	 * 常见问题
	 */
	public function faq(){
	
	}

}