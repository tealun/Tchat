<?php
namespace Wechat\Event;

class LinkEvent{
  
  
}