<?php
namespace Wechat\Event;

class VideoEvent{
	
	
}