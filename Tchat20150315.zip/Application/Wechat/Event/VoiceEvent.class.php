<?php
namespace Wechat\Event;

class VoiceEvent{
	
	
}