grumble.js
==========

Add a bubble to any element; configure its rotation on a 360 degree axis and define its distance from the centre of the element.

Bubble size adapts to contents - perfect when text is localised and size can not be determined up front.

Examples
--------

[grumble.js examples](http://jamescryer.github.com/grumble.js/)

Author
------
James Cryer / Huddle.com

Licence
-------

Do what you like, just don't be an arsehole.